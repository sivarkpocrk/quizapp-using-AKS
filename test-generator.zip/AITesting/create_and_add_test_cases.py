import requests
import base64
import os
import json

# Configuration
organization = "elexonfp"
project = "TestPlan-PoC"
plan_id = 1772
suite_id = 1773
pat = os.getenv("AZDO_PAT")

if not pat:
    raise ValueError("❌ PAT not found. Please set the AZDO_PAT environment variable 'AZDO_PAT'.")

# Authorization header
auth_header = {
    "Authorization": "Basic " + base64.b64encode(f":{pat}".encode()).decode()
}

# Test cases to create
test_cases = [
    {
        "title": "Test Case 1: Validate successful login for registered user",
        "steps": [
            "1. Open any search engine.",
            "2. Type \"Elexon Portal\" in the search bar and hit Enter.",
            "3. Click on the official Elexon Portal website from the search results.",
            "4. Once the page is fully loaded, input the registered username in the 'Username' field.",
            "5. Input the corresponding password in the 'Password' field.",
            "6. Click on the 'Login' button to attempt to log in."
        ],
        "expected_result": "- User is successfully logged into the Elexon Portal with the given username and password."
    },
    {
        "title": "Test Case 2: Validate error message for incorrect credentials",
        "steps": [
            "1. Follow steps 1-4 from Test Case 1.",
            "2. Input an incorrect password in the 'Password' field.",
            "3. Click on the 'Login' button to try logging in."
        ],
        "expected_result": "- User is not logged in and an error message stating incorrect credentials is displayed."
    }
]

# Function to create a test case
def create_test_case(title, steps, expected_result):
    steps_xml = "<steps>"
    for i, step in enumerate(steps, start=1):
        steps_xml += f"<step id=\"{i}\" type=\"Action\">" \
                     f"<parameter name=\"name\" value=\"{step}\"/>" \
                     f"<parameter name=\"expected\" value=\"{expected_result}\"/></step>"
    steps_xml += "</steps>"

    payload = [
        {"op": "add", "path": "/fields/System.Title", "value": title},
        {"op": "add", "path": "/fields/Microsoft.VSTS.TCM.Steps", "value": steps_xml},
        {"op": "add", "path": "/fields/System.AreaPath", "value": f"{project}\\AI"},
        {"op": "add", "path": "/fields/System.IterationPath", "value": f"{project}\\Iteration 1"}
    ]

    url = f"https://dev.azure.com/{organization}/{project}/_apis/wit/workitems/$Test%20Case?api-version=7.0"
    response = requests.post(url, headers={**auth_header, "Content-Type": "application/json-patch+json"}, json=payload)
    print(f"Create Test Case Response: {response.status_code} - {response.text}")
    response.raise_for_status()
    return response.json()["id"]

# Function to add test case to suite
def add_test_case_to_suite(test_case_id):
    url = f"https://dev.azure.com/{organization}/{project}/_apis/test/Plans/{plan_id}/Suites/{suite_id}/TestCases/{test_case_id}?api-version=7.0"
    response = requests.post(url, headers={**auth_header, "Content-Type": "application/json"})
    print(f"Add to Suite Response: {response.status_code} - {response.text}")
    response.raise_for_status()
    return response.status_code in [200, 204]

# Main execution
for tc in test_cases:
    try:
        print(f"🔧 Creating test case: {tc['title']}")
        test_case_id = create_test_case(tc["title"], tc["steps"], tc["expected_result"])
        print(f"✅ Created test case with ID: {test_case_id}")

        print(f"📌 Adding test case ID {test_case_id} to suite {suite_id}")
        if add_test_case_to_suite(test_case_id):
            print(f"✅ Successfully added test case ID {test_case_id} to suite {suite_id}")
        else:
            print(f"⚠️ Failed to add test case ID {test_case_id} to suite {suite_id}")
    except Exception as e:
        print(f"❌ Error processing test case '{tc['title']}': {e}")
