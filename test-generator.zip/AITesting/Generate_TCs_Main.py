import os
from urllib.request import HTTPBasicAuthHandler

import requests
import openai
import re
import json

from Extract_ACs_from_workitem import fetch_acceptance_criteria
from parse_model_result_to_list import parse_test_cases_trial
from openai_model_api_call import generate_tc_from_ai_model
from test_cases_upload import AzureTestCaseUploader
from TC_retrieve import test_retrieve


# Example of calling the function
organization = 'elexonfp'
project = 'TestPlan-PoC'
work_item_id = '1769'
azure_devops_pat = os.getenv("SYSTEM_ACCESSTOKEN")

test_plan_id='1772'
test_suite_id='1773'


api_key = os.getenv("OPENAI_API_KEY")

def generate_test_cases(acceptance_criteria):
    """
    Generates structured test cases based on acceptance criteria using OpenAI GPT-4.

    Args:
        acceptance_criteria (str): The extracted acceptance criteria.

    Returns:
        str: Generated test cases in a structured format.
    """
    print(f"Acceptance Criteria at the start:\n{acceptance_criteria}\n")

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("Error: OPENAI_API_KEY is not set.")
        return "ERROR: Missing API key."

    try:
        openai.api_key = api_key
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert software tester. Generate structured test cases "
                        "based strictly on the given format. Do NOT deviate from this format.\n\n"
                        "FORMAT:\n"
                        "Test Case {X}: [Short Title]\n\n"
                        "Steps:\n"
                        "    1. [Step 1 description]\n"
                        "    2. [Step 2 description]\n"
                        "    3. [Step 3 description]\n\n"
                        "Expected Result:\n"
                        "    - [Expected outcome in bullet points]\n\n"
                        "Pass/Fail Condition:\n"
                        "    - Pass: [Condition for passing]\n"
                        "    - Fail: [Condition for failing]\n\n"
                        "Ensure test cases are detailed but concise."
                    )
                },
                {
                    "role": "user",
                    "content": (
                        f"Based on the following acceptance criteria, generate multiple test cases "
                        f"with detailed steps, expected results, and pass/fail conditions strictly following the format:\n\n"
                        f"{acceptance_criteria}\n\n"
                        "Ensure each test case follows the structure mentioned in the system message."
                    )
                }
            ],
            max_tokens=1500  # Allowing space for detailed test cases
        )

        test_cases = response['choices'][0]['message']['content'].strip()

        print(f"Generated Test Cases:\n{test_cases}\n" + "-" * 50)
        return test_cases

    except Exception as e:
        print(f"Error generating test cases:\n{e}")
        return "ERROR: Failed to generate test cases."

def create_azure_test_case(test_plan_id, test_case_name, test_steps, expected_result, pass_condition, fail_condition):
    """
    Create a test case in Azure DevOps Test Plan.

    Args:
        test_plan_id (str): The ID of the test plan where the test case will be created.
        test_case_name (str): The name/title of the test case.
        test_steps (str): The steps to be performed in the test case.
        expected_result (str): The expected result of the test case.
        pass_condition (str): The pass condition of the test case.
        fail_condition (str): The fail condition of the test case.

    Returns:
        str: Result of the test case creation.
    """
    azure_devops_url = f"https://dev.azure.com/{organization}/{project}/_apis/test/Runs/{test_plan_id}/TestCases?api-version=6.0"

    headers = {
        'Content-Type': 'application/json',
    }

    test_case_payload = {
        "fields": {
            "System.Title": test_case_name,
            "Microsoft.VSTS.TCM.Steps": [
                {
                    "id": 1,
                    "action": test_steps,
                    "expectedResult": expected_result,
                    "manualTestingInstructions": pass_condition
                }
            ],
            "System.Description": fail_condition
        }
    }

    response = requests.post(
        azure_devops_url,
        headers=headers,
        json=test_case_payload,
        auth=HTTPBasicAuthHandler("", azure_devops_pat)
    )

    if response.status_code == 201:
        print(f"Test case '{test_case_name}' created successfully in Azure DevOps.")
        return response.json()
    else:
        print(f"Error creating test case: {response.status_code} - {response.text}")
        return None

def main():
    """
    Reads the acceptance criteria from ac.txt, generates multiple test cases, and saves them to 'generated_test_script.txt'.
    """
    ac_file = "ac.txt"
    output_file = "generated_test_script_TC_Main.txt"

    test_ret = test_retrieve()

    acceptance_criteria = fetch_acceptance_criteria(organization, project, work_item_id, azure_devops_pat)
    print("Acceptance Criteria through called Method:", acceptance_criteria)

    # Generate test cases
    # generated_tests = generate_test_cases(acceptance_criteria)
    generated_tests = generate_tc_from_ai_model(acceptance_criteria, api_key)

    # Save generated test cases to the output file
    with open(output_file, "w", encoding="utf-8") as output:
        output.write(generated_tests)

    print(f"Generated test cases saved to {output_file}")

    parsed_test_case_trial = parse_test_cases_trial(generated_tests)
    
    print("parsed test cases - trail:-/n")
    print(list(parsed_test_case_trial))
    print(json.dumps(parsed_test_case_trial, indent=4))
    print("parsed end test cases - trial:-/n")

    uploader = AzureTestCaseUploader(organization, project, test_plan_id, test_suite_id, work_item_id, azure_devops_pat)
    
    uploader.upload_test_cases(parsed_test_case_trial)


if __name__ == "__main__":
    main()
