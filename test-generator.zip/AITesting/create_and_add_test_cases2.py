import os
import base64
import requests
import json

# ─── CONFIGURATION ────────────────────────────────────────────────────────────
org     = "elexonfp"                    # your Azure DevOps organization
proj    = "TestPlan-PoC"                # your Azure DevOps project
pat     = os.getenv("AZURE_DEVOPS_PAT") # set this as a secret pipeline variable
if not pat:
    raise ValueError("❌ Please set AZURE_DEVOPS_PAT")

# ─── AUTH HEADER ───────────────────────────────────────────────────────────────
credentials = f":{pat}".encode()
headers = {
    "Content-Type": "application/json-patch+json",
    "Authorization":  "Basic " + base64.b64encode(credentials).decode()
}

# ─── BUILD THE STEPS XML ───────────────────────────────────────────────────────
steps = [
    {"action": "Open any search engine.",                 "expected": "Search engine homepage loads."},
    {"action": "Type 'Elexon Portal' and press Enter.",    "expected": "Search results appear."},
    {"action": "Click the official Elexon Portal link.",   "expected": "Elexon Portal login page loads."},
    {"action": "Enter valid username and password.",       "expected": "Credentials accepted."},
    {"action": "Click the 'Login' button.",                "expected": "User is redirected to dashboard."}
]

last_step_id = len(steps)
xml = f'<steps id="0" last="{last_step_id}">'
for idx, s in enumerate(steps, start=1):
    xml += (
        f'<step type="ActionStep" id="{idx}">'
        f'<parameterizedString isformatted="true">{s["action"]}</parameterizedString>'
        f'<parameterizedString isformatted="true">{s["expected"]}</parameterizedString>'
        f'</step>'
    )
xml += "</steps>"

# ─── JSON-PATCH DOCUMENT ───────────────────────────────────────────────────────
patch_document = [
    {"op":"add","path":"/fields/System.Title","value":"Automated login test creation working"},
    {"op":"add","path":"/fields/Microsoft.VSTS.TCM.Steps","value": xml},
    {"op":"add","path":"/fields/System.AreaPath","value": f"{proj}\\AI"},
    {"op":"add","path":"/fields/System.IterationPath","value": f"{proj}\\Iteration 1"}
]

# ─── CREATE THE TEST CASE ─────────────────────────────────────────────────────
url = (f"https://dev.azure.com/{org}/{proj}/_apis/wit/workitems/$Test%20Case?api-version=7.0")

resp = requests.post(url, headers=headers, json=patch_document)
resp.raise_for_status()

tc = resp.json()
print(f"✅ Created Test Case ID: {tc['id']}")
print(json.dumps(tc, indent=2))
