import os
import openai


def generate_tc_from_ai_model(acceptance_criteria, api_key):
    """
    Generates structured test cases based on acceptance criteria using OpenAI GPT-4.

    Args:
        acceptance_criteria (str): The extracted acceptance criteria.

    Returns:
        str: Generated test cases in a structured format.
    """
    print(f"Acceptance Criteria at the start:\n{acceptance_criteria}\n")

    if not api_key:
        print("Error: OPENAI_API_KEY is not set.")
        return "ERROR: Missing API key."

    try:
        openai.api_key = api_key
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert software tester. Generate structured test cases "
                        "based strictly on the given format. Do NOT deviate from this format.\n\n"
                        "FORMAT:\n"
                        "Test Case {X}: [Short Title]\n\n"
                        "Steps:\n"
                        "    1. [Step 1 description]\n"
                        "    2. [Step 2 description]\n"
                        "    3. [Step 3 description]\n\n"
                        "Expected Result:\n"
                        "    - [Expected outcome in bullet points]\n\n"
                        "Pass/Fail Condition:\n"
                        "    - Pass: [Condition for passing]\n"
                        "    - Fail: [Condition for failing]\n\n"
                        "Ensure test cases are detailed but concise."
                    )
                },
                {
                    "role": "user",
                    "content": (
                        f"Based on the following acceptance criteria, generate multiple test cases "
                        f"with detailed steps, expected results, and pass/fail conditions strictly following the format:\n\n"
                        f"{acceptance_criteria}\n\n"
                        "Ensure each test case follows the structure mentioned in the system message."
                    )
                }
            ],
            max_tokens=1500  # Allowing space for detailed test cases
        )

        test_cases = response['choices'][0]['message']['content'].strip()

        print(f"Generated Test Cases:\n{test_cases}\n" + "-" * 50)
        return test_cases

    except Exception as e:
        print(f"Error generating test cases:\n{e}")
        return "ERROR: Failed to generate test cases."