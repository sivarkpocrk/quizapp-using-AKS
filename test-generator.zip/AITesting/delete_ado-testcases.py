"""
Script to permanently delete Azure DevOps Test Case work items within a specified ID range.

Usage:
    python delete_ado_testcases.py \
        --org-url https://dev.azure.com/yourorg \
        --pat YOUR_PERSONAL_ACCESS_TOKEN \
        --start-id 100 \
        --end-id 200
"""
import argparse
import sys
from azure.devops.connection import Connection
from msrest.authentication import BasicAuthentication
from azure.devops.exceptions import AzureDevOpsServiceError


def delete_test_cases(org_url: str, pat: str, start_id: int, end_id: int):
    # Authenticate
    credentials = BasicAuthentication("", pat)
    connection = Connection(base_url=org_url, creds=credentials)
    wit_client = connection.clients.get_work_item_tracking_client()

    # Iterate through the specified range
    for work_item_id in range(start_id, end_id + 1):
        try:
            wi = wit_client.get_work_item(work_item_id, expand="None")
            wi_type = wi.fields.get("System.WorkItemType", "")

            if wi_type.lower() == "test case":
                print(f"Deleting Test Case #{work_item_id}...")
                # Permanently delete (destroy=True)
                wit_client.delete_work_item(work_item_id, destroy=True)
                print(f"--> Deleted Test Case #{work_item_id}")
            else:
                print(f"Skipping #{work_item_id}: not a Test Case (type={wi_type})")
        except AzureDevOpsServiceError as err:
            print(f"Error with ID {work_item_id}: {err}")
        except Exception as ex:
            print(f"Unexpected error on ID {work_item_id}: {ex}")


def main():
    parser = argparse.ArgumentParser(
        description="Delete ADO Test Case work items in a given ID range"
    )
    parser.add_argument(
        "--org-url", required=True,
        help="Azure DevOps organization URL (e.g., https://dev.azure.com/yourorg)"
    )
    parser.add_argument(
        "--pat", required=True,
        help="Personal Access Token with work item delete permissions"
    )
    parser.add_argument(
        "--start-id", type=int, required=True,
        help="Start of work item ID range (inclusive)"
    )
    parser.add_argument(
        "--end-id", type=int, required=True,
        help="End of work item ID range (inclusive)"
    )

    args = parser.parse_args()

    if args.start_id > args.end_id:
        print("Error: start-id must be less than or equal to end-id.", file=sys.stderr)
        sys.exit(1)

    delete_test_cases(args.org_url, args.pat, args.start_id, args.end_id)


if __name__ == '__main__':
    main()
