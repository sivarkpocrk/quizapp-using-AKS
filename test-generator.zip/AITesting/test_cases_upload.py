import os
import json
import requests
from requests.auth import HTTPBasicAuth

class AzureTestCaseUploader:
    def __init__(self, organization, project, test_plan_id, test_suite_id, user_story_id, azure_devops_pat):
        """
        Initializes the AzureTestCaseUploader with the required details.
        
        Args:
            organization_name (str): Your Azure DevOps organization name.
            project_name (str): Your Azure DevOps project name.
            test_plan_id (str): ID of the test plan.
            test_suite_id (str): ID of the test suite.
            user_story_id (str): ID of the user story to link test cases.
            pat (str): Azure DevOps Personal Access Token (PAT).
        """
        self.organization = organization
        self.project = project
        self.test_plan_id = test_plan_id
        self.test_suite_id = test_suite_id
        self.user_story_id = user_story_id
        self.azure_devops_pat = azure_devops_pat
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {self.azure_devops_pat}"  # Use the PAT directly here
        }
        self.base_url = f"https://dev.azure.com/{self.organization}/{self.project}/_apis"

    def test_posapi(self):

        # API URL for creating a test case
        url = f"https://dev.azure.com/{self.organization}/{self.project}/_apis/wit/workitems/$Test%20Case?api-version=7.1-preview.1"

        # Correct authentication
        auth = HTTPBasicAuth("", self.azure_devops_pat)

        # Headers
        headers = {
            "Content-Type": "application/json-patch+json"
        }

        # Test case payload (formatted properly)
        payload = [
            {"op": "add", "path": "/fields/System.Title", "value": "Test Case 1: User Navigation to Elexon Portal"},
            {"op": "add", "path": "/fields/Microsoft.VSTS.TCM.Steps", "value": "<steps><step action='1. Open any web browser.' expected='The Elexon Portal appears in the search results.'/><step action='2. Input Elexon Portal in the search bar and hit enter.' expected='The Elexon Portal appears in the search results.'/></steps>"},
            {"op": "add", "path": "/fields/System.State", "value": "Design"}
        ]

        # Send the request
        response = requests.post(url, headers=headers, auth=auth, json=payload)

        # Handle empty response properly
        try:
            response_json = response.json()
        except requests.exceptions.JSONDecodeError:
            response_json = {"error": "Empty response from server"}

        # Check the response
        if response.status_code in [200, 201]:
            test_case_id = response_json.get("id", "Unknown")
            print(f"✅ Test case created successfully. ID: {test_case_id}")
        else:
            print(f"❌ Failed to create test case. Status code: {response.status_code}")
            print(response_json)

    
    def create_test_case(self, title, steps):
        """
        Creates a test case in Azure DevOps Test Plan.
        """
        url = f"{self.base_url}/test/plans/{self.test_plan_id}/suites/{self.test_suite_id}/testcases?api-version=7.1-preview.1"

        url = f'https://dev.azure.com/{self.organization}/{self.project}/_apis/test/Plans/{self.test_plan_id}/Suites/{self.test_suite_id}/TestCases?api-version=7.0'

        print(f'Data - URL Detail: {url}')
        
        payload = {
            "testCase": {
                "name": title,
                "steps": [{"action": step["action"], "expectedResult": step["expected"]} for step in steps]
            }
        }
        
        print(f'Payload Detail: {payload}')

        auth = HTTPBasicAuth("", self.azure_devops_pat)
        headers = {
            "Content-Type": "application/json-patch+json"  # Required for test case creation
        }
        response = requests.post(url, headers=headers, auth=auth, json=payload)

        print(response.json)

        if response.status_code == 200 or response.status_code == 201:
            test_case_id = response.json()["id"]
            print(f"Created Test Case: {title} (ID: {test_case_id})")
            return test_case_id
        else:
            print(f"Error Creating Test Case: {title} - {response.text}")
            return None

    def link_test_case_to_user_story(self, test_case_id):
        """
        Links the created test case to a User Story in Azure DevOps.
        """
        url = f"{self.base_url}/wit/workitems/{test_case_id}?api-version=7.1-preview.3"
        
        payload = [
            {
                "op": "add",
                "path": "/relations/-",
                "value": {
                    "rel": "System.LinkTypes.Hierarchy-Reverse",
                    "url": f"{self.base_url}/wit/workitems/{self.user_story_id}"
                }
            }
        ]

        response = requests.patch(url, headers=self.headers, json=payload)
        
        if response.status_code == 200:
            print(f"Linked Test Case {test_case_id} to User Story {self.user_story_id}")
        else:
            print(f"Error Linking Test Case: {response.text}")

    def upload_test_cases(self, test_cases):
        """
        Uploads test cases to Azure DevOps under a test plan.
        """
        if not test_cases:
            print("No test cases provided.")
            return

        test1 = self.test_posapi()

        for tc_data in test_cases:  # Looping through the list directly
            title = tc_data["test_case_name"]

            steps = []

            # Assuming test steps are formatted as a string with line breaks
            for idx, step in enumerate(tc_data.get("test_steps", "").split("\n")):
                steps.append({
                    "action": step.strip(),
                    "expected": tc_data.get("expected_result", "")
                })

            # Create test case under test plan
            test_case_id = self.create_test_case(title, steps)

            if test_case_id:
                print(f"✅ Test case '{title}' created with ID: {test_case_id}")
            else:
                print(f"❌ Failed to create test case: {title}")


