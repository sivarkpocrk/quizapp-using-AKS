import os
import base64
import requests
import json

# ─── CONFIGURATION ────────────────────────────────────────────────────────────
org      = "elexonfp"                     # your Azure DevOps organization
proj     = "TestPlan-PoC"                 # your Azure DevOps project
plan_id  = 1772                           # your Test Plan ID
suite_id = 1773                           # your Test Suite ID
pat      = os.getenv("AZURE_DEVOPS_PAT")  # set this as a secret pipeline variable

if not pat:
    raise ValueError("❌ Please set AZURE_DEVOPS_PAT environment variable")

# ─── AUTH HEADER ───────────────────────────────────────────────────────────────
credentials = f":{pat}".encode()
auth_header = {
    "Authorization": "Basic " + base64.b64encode(credentials).decode()
}
wi_headers = {
    **auth_header,
    "Content-Type": "application/json-patch+json"
}

# ─── FUNCTIONS ─────────────────────────────────────────────────────────────────
def build_steps_xml(steps_list):
    """
    Build the XML string for a list of step dictionaries
    Each step dict should have 'action' and 'expected' keys
    """
    last_step_id = len(steps_list)
    xml = f'<steps id="0" last="{last_step_id}">'
    for idx, s in enumerate(steps_list, start=1):
        xml += (
            f'<step type="ActionStep" id="{idx}">'
            f'<parameterizedString isformatted="true">{s["action"]}</parameterizedString>'
            f'<parameterizedString isformatted="true">{s["expected"]}</parameterizedString>'
            f'</step>'
        )
    xml += "</steps>"
    return xml


def create_test_case(title, steps_xml):
    """
    Create a new Test Case work item in Azure DevOps
    """
    url = f"https://dev.azure.com/{org}/{proj}/_apis/wit/workitems/$Test%20Case?api-version=7.0"
    patch_document = [
        {"op": "add", "path": "/fields/System.Title", "value": title},
        {"op": "add", "path": "/fields/Microsoft.VSTS.TCM.Steps", "value": steps_xml},
        {"op": "add", "path": "/fields/System.AreaPath", "value": f"{proj}\\AI"},
        {"op": "add", "path": "/fields/System.IterationPath", "value": f"{proj}\\Iteration 1"}
    ]

    resp = requests.post(url, headers=wi_headers, json=patch_document)
    resp.raise_for_status()
    tc = resp.json()
    print(f"✅ Created Test Case '{title}' (ID: {tc['id']})")
    return tc['id']


def add_test_case_to_suite(test_case_id):
    """
    Add an existing Test Case to the given Test Plan and Suite
    """
    url = (f"https://dev.azure.com/{org}/{proj}/_apis/test/Plans/{plan_id}" \
           f"/Suites/{suite_id}/TestCases/{test_case_id}?api-version=7.0")
    resp = requests.post(url, headers=auth_header)
    resp.raise_for_status()
    if resp.status_code in (200, 204):
        print(f"✅ Added Test Case ID {test_case_id} to Suite {suite_id}")
    else:
        print(f"⚠️ Unexpected response {resp.status_code}: {resp.text}")


def load_test_definitions(json_path):
    """
    Load a JSON file containing a list of test case definitions.
    Each definition should have 'title' and 'steps' (list of action/expected dicts).
    """
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data


if __name__ == "__main__":
    # Path to your JSON file with generated test cases
    json_file = "generated_test_cases_example.json"
    if not os.path.exists(json_file):
        raise FileNotFoundError(f"JSON file '{json_file}' not found.")
    test_defs = load_test_definitions(json_file)

    for td in test_defs:
        title = td.get('title')
        steps = td.get('steps', [])
        if not title or not steps:
            print(f"⚠️ Skipping invalid test definition: {td}")
            continue
        steps_xml = build_steps_xml(steps)
        tc_id = create_test_case(title, steps_xml)
        add_test_case_to_suite(tc_id)
