import re

def parse_test_cases_trial(test_case_text):
    """
    Parses multiple test cases from structured text.

    Args:
        test_case_text (str): The full text containing multiple test cases.

    Returns:
        list: A list of dictionaries containing test case details.
    """
    test_cases = []
    
    # Regex pattern to match test case headers (e.g., "Test Case 1: <Title>")
    test_case_pattern = re.compile(r"(Test Case \d+: .+?)(?=Test Case \d+:|$)", re.DOTALL)
    
    # Find all test cases in the input text
    sections = test_case_pattern.findall(test_case_text)
    
    for section in sections:
        # Split the test case header and body
        test_case_header, test_case_body = section.split("\n", 1)
        
        test_case_name = test_case_header.strip()
        
        test_steps = []
        expected_result = ""
        pass_condition = ""
        fail_condition = ""

        # Splitting test case body by lines
        lines = test_case_body.split("\n")

        # Flags to determine which section we're in
        is_test_steps = False
        is_expected_result = False

        for line in lines:
            line = line.strip()

            if line.startswith("Steps:"):
                is_test_steps = True
                is_expected_result = False
                continue
            elif line.startswith("Expected Result:"):
                is_test_steps = False
                is_expected_result = True
                expected_result = line.replace("Expected Result:", "").strip()
                continue
            elif line.startswith("Pass/Fail Condition:"):
                is_test_steps = False
                is_expected_result = False
                continue
            elif line.startswith("- Pass:"):
                pass_condition = line.replace("- Pass:", "").strip()
                continue
            elif line.startswith("- Fail:"):
                fail_condition = line.replace("- Fail:", "").strip()
                continue

            # Capture multi-line expected result if in that section
            if is_expected_result:
                if line:
                    expected_result += "\n" + line.strip()

            if is_test_steps and line:
                test_steps.append(line)

        # Store parsed test case data
        test_cases.append({
            "test_case_name": test_case_name,
            "test_steps": "\n".join(test_steps),
            "expected_result": expected_result,
            "pass_condition": pass_condition,
            "fail_condition": fail_condition
        })

    return test_cases