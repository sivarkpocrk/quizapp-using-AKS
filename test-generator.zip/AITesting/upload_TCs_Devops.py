import requests
import json
import base64
import os

# Configuration
organization = "elexonfp"  # Replace with your organization name
project = "TestPlan-PoC"  # Replace with your project name
pat = "2bO7KJEL3AZp7EDx3kTI37Nqmn9WWoR2tNj9kuUlWZt56nzOn1ScJQQJ99BFACAAAAAHkvmRAAASAZDOqNMM"  # Replace with your PAT (Do not expose in public)


if not pat:
   raise ValueError("❌ PAT not found. Please set the AZDO_PAT environment variable.")

# API URL
url = f"https://dev.azure.com/{organization}/{project}/_apis/wit/workitems/$Test%20Case?api-version=7.0"

# Proper JSON Patch format for work item creation
test_case_data = [
    {
        "op": "add",
        "path": "/fields/System.Title",
        "value": "Automated Test Case Example"
    },
    {
        "op": "add",
        "path": "/fields/Microsoft.VSTS.TCM.Steps",
        "value": "<steps><step id=\"1\" type=\"Action\"><parameter name=\"name\" value=\"Step 1: Open the application\"/></step><step id=\"2\" type=\"Action\"><parameter name=\"name\" value=\"Step 2: Enter username and password\"/></step></steps>"
    },
    {
        "op": "add",
        "path": "/fields/System.AreaPath",
        "value": f"{project}\\AI"  # Adjust as per your area path
    },
    {
        "op": "add",
        "path": "/fields/System.IterationPath",
        "value": f"{project}\\Iteration 1"  # Adjust as per your iteration path
    }
]

# Set up headers correctly
headers = {
    "Content-Type": "application/json-patch+json",
    "Authorization": "Basic " + base64.b64encode(f":{pat}".encode()).decode()
}

# Send request to Azure DevOps API
try:
    response = requests.post(url, headers=headers, json=test_case_data)
    response.raise_for_status()  # Raises error for 4xx and 5xx status codes

    created_test_case = response.json()
    print(f"✅ Test case created successfully. ID: {created_test_case['id']}")
    print(json.dumps(created_test_case, indent=4))  # Pretty print response

except requests.exceptions.RequestException as e:
    print(f"❌ Error creating test case: {e}")
    if response is not None:
        print(response.text)  # Print detailed error message
except Exception as e:
    print(f"⚠️ A general error occurred: {e}")
