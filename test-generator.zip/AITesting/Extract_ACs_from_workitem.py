import os
from requests.auth import HTTPBasicAuth
import requests
import html2text

def fetch_acceptance_criteria(organization, project, work_item_id, azure_devops_pat):
    """
    Fetches the acceptance criteria from a given work item in Azure DevOps.

    Args:
        organization (str): The Azure DevOps organization name.
        project (str): The Azure DevOps project name.
        work_item_id (str): The work item ID to fetch.
        azure_devops_pat (str): The Azure DevOps personal access token.

    Returns:
        str: The cleaned acceptance criteria or an error message if something fails.
    """
    if not azure_devops_pat:
        return "ERROR: SYSTEM_ACCESSTOKEN not found. Check pipeline settings."

    print(f"Fetching acceptance criteria for Work Item ID: {work_item_id}...")

    # Azure DevOps API details
    org_url = f"https://dev.azure.com/{organization}"
    api_url = f"{org_url}/{project}/_apis/wit/workitems/{work_item_id}?api-version=6.0"

    auth = HTTPBasicAuth("", azure_devops_pat)
    headers = {
        "Content-Type": "application/json"
    }

    # Make the API request
    response = requests.get(api_url, headers=headers, auth=auth)

    if response.status_code == 401:
        return "ERROR: Unauthorized. Please check the PAT permissions."

    if response.status_code != 200:
        return f"ERROR: Failed to fetch work item. Status code: {response.status_code}"

    work_item = response.json()

    # Extract acceptance criteria
    ac_raw = work_item['fields'].get('Microsoft.VSTS.Common.AcceptanceCriteria', 'No acceptance criteria found')
    ac_clean = html2text.html2text(ac_raw).strip()

    return ac_clean


