import requests
import base64

# Configuration
organization = "elexonfp"  # Replace with your organization name
project = "TestPlan-PoC"   # Replace with your project name
pat = "2bO7KJEL3AZp7EDx3kTI37Nqmn9WWoR2tNj9kuUlWZt56nzOn1ScJQQJ99BFACAAAAAHkvmRAAASAZDOqNMM"     # Replace with your Personal Access Token

# API endpoint
url = f"https://dev.azure.com/{organization}/{project}/_apis/wit/workitemtypes?api-version=7.0"

# Set up headers
headers = {
    "Authorization": "Basic " + base64.b64encode(f":{pat}".encode()).decode()
}

# Make the request
try:
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    work_item_types = response.json()

    print("✅ Available Work Item Types:")
    for item in work_item_types["value"]:
        print(f"- {item['name']}")

except requests.exceptions.RequestException as e:
    print(f"❌ Error fetching work item types: {e}")
    if response is not None:
        print(response.text)
