import os
import base64
import requests
import json

# ─── CONFIGURATION ────────────────────────────────────────────────────────────
org      = "elexonfp"                     # your Azure DevOps organization
proj     = "TestPlan-PoC"                 # your Azure DevOps project
plan_id  = 1772                           # your Test Plan ID
suite_id = 1773                           # your Test Suite ID
pat      = os.getenv("AZURE_DEVOPS_PAT")  # set this as a secret pipeline variable

if not pat:
    raise ValueError("❌ Please set AZURE_DEVOPS_PAT")

# ─── AUTH HEADER ───────────────────────────────────────────────────────────────
credentials = f":{pat}".encode()
auth_header = {
    "Authorization": "Basic " + base64.b64encode(credentials).decode()
}
wi_headers = {
    **auth_header,
    "Content-Type": "application/json-patch+json"
}

# ─── BUILD THE STEPS XML ───────────────────────────────────────────────────────
steps = [
    {"action": "Open any search engine.",              "expected": "Search engine homepage loads."},
    {"action": "Type 'Elexon Portal' and press Enter.","expected": "Search results appear."},
    {"action": "Click the official Elexon Portal link.","expected": "Elexon Portal login page loads."},
    {"action": "Enter valid username and password.",    "expected": "Credentials accepted."},
    {"action": "Click the 'Login' button.",             "expected": "User is redirected to dashboard."}
]

last_step_id = len(steps)
xml = f'<steps id="0" last="{last_step_id}">'
for idx, s in enumerate(steps, start=1):
    xml += (
        f'<step type="ActionStep" id="{idx}">'
        f'<parameterizedString isformatted="true">{s["action"]}</parameterizedString>'
        f'<parameterizedString isformatted="true">{s["expected"]}</parameterizedString>'
        f'</step>'
    )
xml += "</steps>"

# ─── FUNCTION: CREATE A TEST CASE WORK-ITEM ────────────────────────────────────
def create_test_case(title, steps_xml):
   
    url = (f"https://dev.azure.com/{org}/{proj}/_apis/wit/workitems/$Test%20Case?api-version=7.0")
    
    patch_document = [
        {"op":"add","path":"/fields/System.Title","value": title},
        {"op":"add","path":"/fields/Microsoft.VSTS.TCM.Steps","value": steps_xml},
        {"op":"add","path":"/fields/System.AreaPath","value": f"{proj}\\AI"},
        {"op":"add","path":"/fields/System.IterationPath","value": f"{proj}\\Iteration 1"}
    ]

    resp = requests.post(url, headers=wi_headers, json=patch_document)
    resp.raise_for_status()
    tc = resp.json()
    print(f"✅ Created Test Case ID: {tc['id']}")
    return tc["id"]

# ─── FUNCTION: ADD A TEST CASE INTO A SUITE ───────────────────────────────────
def add_test_case_to_suite(test_case_id):
    """
    Adds the given work-item ID into the specified Test Plan/Suite.
    """
    url = (f"https://dev.azure.com/{org}/{proj}/_apis/test/Plans/{plan_id}/Suites/{suite_id}/TestCases/{test_case_id}?api-version=7.0")

    # No JSON body needed; the REST endpoint infers TestCase ID from URL
    resp = requests.post(url, headers=auth_header)
    resp.raise_for_status()
    if resp.status_code in (200, 204):
        print(f"✅ Test Case {test_case_id} added to Suite {suite_id}")
    else:
        print(f"⚠️ Unexpected response {resp.status_code}: {resp.text}")

# ─── MAIN EXECUTION ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    title = "Automated login test for Elexon Portal"
    tc_id = create_test_case(title, xml)
    add_test_case_to_suite(tc_id)
