# File: pipeline_orchestrator.py
import os, sys, argparse, json, base64, requests
from typing import List
from urllib.parse import urlparse
# from generate_test_cases_format import generate_test_cases
# from create_and_add_test_cases2suite_json import add_test_case_to_suite, build_steps_xml
import openai
import html2text
from bs4 import BeautifulSoup
import html
import re


def get_auth_header(pat: str):
    cred = f":{pat}".encode()
    return {"Authorization": "Basic " + base64.b64encode(cred).decode()}


def fetch_workitem(org: str, proj: str, wi_id: str, token: str) -> dict:
    url = f"https://dev.azure.com/{org}/{proj}/_apis/wit/workitems/{wi_id}?api-version=6.0"
    hdr = get_auth_header(token)
    r = requests.get(url, headers=hdr)
    r.raise_for_status()
    return r.json()


def extract_ac(fields: dict) -> str:
    # grab whatever’s in the AcceptanceCriteria field
    ac_html = fields.get("Microsoft.VSTS.Common.AcceptanceCriteria", "")
    if not ac_html:
        return ""

    # parse and strip all tags
    soup = BeautifulSoup(ac_html, 'html.parser')
    # soup = BeautifulSoup(ac_html, 'lxml')

    text = soup.get_text(separator="\n")

    # un-escape any HTML entities (e.g. &nbsp;, &amp;, etc.)
    text = html.unescape(text)

    # collapse multiple blank lines into a single blank line
    text = re.sub(r'\n\s*\n+', '\n\n', text)

    return text.strip()

def generate_test_cases(acceptance_criteria, PAT_AI_KEY):
    """
    Generates structured test cases based on acceptance criteria using OpenAI GPT-4.

    Returns:
        tuple: A list of test case dicts and the raw Python code string defining `test_cases`.
    """
    print(f"inside generate_test_cases …") 
    # Ensure API key is set
    # openai.api_key = os.getenv("OPENAI_API_KEY")

    openai.api_key = PAT_AI_KEY

    if not openai.api_key:
        print("Error: OPENAI_API_KEY is not set.", file=sys.stderr)
        sys.exit(1)

    # System prompt: enforce exact Python output format
    system_prompt = (
        "You are an expert software tester. "
        "When you output your test cases, format them *only* as a Python variable named `test_cases` "
        "and assign it a list of dicts, where each dict has:\n"
        "- a string field `title`\n"
        "- a list field `steps`, each item of which is a dict with:\n"
        "    - string field `action`\n"
        "    - string field `expected`\n\n"
        "Do not wrap your answer in prose—output *only* valid Python code, e.g.:\n"
        "```python\n"
        "test_cases = [\n"
        "    {\n"
        "        \"title\": \"...\",\n"
        "        \"steps\": [\n"
        "            {\"action\": \"...\", \"expected\": \"...\"},\n"
        "            ...\n"
        "        ]\n"
        "    },\n"
        "    ...\n"
        "]\n"
        "```"
    )

    # Prepare messages
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"Based on the following acceptance criteria, generate test cases:\n\n{acceptance_criteria}"}
    ]

    try:
        # Call OpenAI API
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=messages,
            max_tokens=1500,
            temperature=0
        )
        raw_content = response.choices[0].message.content.strip()

        print(f"after open AI Step …") 

        # Execute the returned code to extract `test_cases`
        namespace = {}
        exec(raw_content, {}, namespace)
        test_cases = namespace.get("test_cases")


        print(f"Generated Test Cases:\n{test_cases}\n" + "-" * 50)

        print(f"Generated Test Cases Raw Content:\n{raw_content}\n" + "-" * 50)

        if test_cases is None:
            print("Error: 'test_cases' variable not found in the model response.", file=sys.stderr)
            sys.exit(1)

        return test_cases, raw_content

    except Exception as e:
        print(f"Error generating test cases: {e}", file=sys.stderr)
        sys.exit(1)


# ─── FUNCTIONS ─────────────────────────────────────────────────────────────────
def build_steps_xml(steps_list):
    """
    Build the XML string for a list of step dictionaries
    Each step dict should have 'action' and 'expected' keys
    """
    last_step_id = len(steps_list)
    xml = f'<steps id="0" last="{last_step_id}">'
    for idx, s in enumerate(steps_list, start=1):
        xml += (
            f'<step type="ActionStep" id="{idx}">'
            f'<parameterizedString isformatted="true">{s["action"]}</parameterizedString>'
            f'<parameterizedString isformatted="true">{s["expected"]}</parameterizedString>'
            f'</step>'
        )
    xml += "</steps>"
    return xml


def create_test_case(org, proj, pat, plan_id, suite_id, title, steps_xml):
    # create work item
    url = f"https://dev.azure.com/{org}/{proj}/_apis/wit/workitems/$Test%20Case?api-version=7.0"
    body = [
        {"op": "add", "path": "/fields/System.Title", "value": title},
        {"op": "add", "path": "/fields/Microsoft.VSTS.TCM.Steps", "value": steps_xml},
        {"op": "add", "path": "/fields/System.AreaPath", "value": f"{proj}\\AI"},
        {"op": "add", "path": "/fields/System.IterationPath", "value": f"{proj}\\Iteration 1"}
    ]
    hdr = get_auth_header(pat)
    hdr["Content-Type"] = "application/json-patch+json"
    r = requests.post(url, headers=hdr, json=body)
    r.raise_for_status()
    tc_id = r.json()["id"]

    # add to suite
    url2 = (
        f"https://dev.azure.com/{org}/{proj}/_apis/test/Plans/{plan_id}"
        f"/Suites/{suite_id}/TestCases/{tc_id}?api-version=7.0"
    )
    r2 = requests.post(url2, headers=get_auth_header(pat))
    r2.raise_for_status()
    print(f"✅ TC {tc_id} added to Suite {suite_id}")
    return tc_id

def link_test_case_to_user_story(org, proj, pat, test_case_id, user_story_id):
    url = f"https://dev.azure.com/{org}/{proj}/_apis/wit/workitems/{test_case_id}?api-version=7.0"
    headers = get_auth_header(pat)
    headers["Content-Type"] = "application/json-patch+json"

    body = [
        {
            "op": "add",
            "path": "/relations/-",
            "value": {
                "rel": "System.LinkTypes.Hierarchy-Reverse",
                "url": f"https://dev.azure.com/{org}/{proj}/_apis/wit/workitems/{user_story_id}",
                "attributes": {
                    "comment": "Linked test case to user story via automation"
                }
            }
        }
    ]

    r = requests.patch(url, headers=headers, json=body)
    r.raise_for_status()
    print(f"🔗 Linked Test Case {test_case_id} to User Story {user_story_id}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work-item-ids", required=True,
                        help="Comma-separated Work Item IDs")
    parser.add_argument("--plan-id", required=True)
    parser.add_argument("--suite-id", required=True)
    # parser.add_argument("--use-ai", action="store_true")
    args = parser.parse_args()

    pat = os.getenv("AZURE_DEVOPS_PAT")  # or os.getenv("SYSTEM_ACCESSTOKEN")

 
    PAT_AI_KEY = os.getenv("OPENAI_API_KEY")

    # org = os.getenv("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI").split("://")[1].split("/")[0]

    collection_uri = os.getenv("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI", "")
    print(f"collection_uri - :  {collection_uri}")

    parsed = urlparse(collection_uri)
    print(f"collection_uri - parsed:  {parsed}")
    
    print(f"collection_uri - parsed-path:  {parsed.path.strip("/")}")

    org = parsed.path.strip("/").split("/", 1)[0]

    proj = os.getenv("SYSTEM_TEAMPROJECT")

    print(f"Processing Work Item - pat {pat}…")
    print(f"Processing Work Item - org {org}…")
    print(f"Processing Work Item - proj {proj}…")

    # split and process each WI
    for wi in args.work_item_ids.split(','):
      
        wi = wi.strip().strip('"').strip("'")
        print(f"Processing Work Item {wi}…")

        wi_json = fetch_workitem(org, proj, wi, pat)
        acceptance_criteria = extract_ac(wi_json.get('fields', {}))
        
        print(f"Extracted ACs: {acceptance_criteria} ")


        # if args.use_ai:
        #     if not openai:
        #         sys.exit("❌ openai lib missing")
        #     openai.api_key = os.getenv("OPENAI_API_KEY")
        #     # test_defs = generate_tests_via_ai(ac)
        #     test_cases_json, raw_code = generate_test_cases(pat, ac)
        # else:
        #     test_defs = [{
        #         "title": f"Validate AC for WI {wi}",
        #         "steps": [{"action": ac, "expected": "Acceptance met"}]
        #     }]

        test_cases, raw_code = generate_test_cases(acceptance_criteria, PAT_AI_KEY)
        
        json_str = json.dumps(test_cases, indent=4)

        test_cases_json = json.loads(json_str)

        for td in test_cases_json:
            title = td.get('title')
            steps = td.get('steps', [])
            if not title or not steps:
                print(f"⚠️ Skipping invalid test definition: {td}")
                continue
            steps_xml = build_steps_xml(steps)
            
            tc_id = create_test_case(org, proj, pat,
                             args.plan_id, args.suite_id,
                             title, steps_xml)
            
            print(f"TC created: {tc_id} ")

            link_test_case_to_user_story(org, proj, pat, tc_id, wi)


if __name__ == "__main__":
    main()
