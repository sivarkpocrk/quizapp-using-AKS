import requests
import json
from requests.auth import HTTPBasicAuth
import os



def test_retrieve():

    # Azure DevOps details
    organization = "elexonfp"
    project = "TestPlan-PoC"
    plan_id = "1772"   # Replace with your Test Plan ID
    suite_id = "1773"  # Replace with your Test Suite ID
    pat = os.getenv("SYSTEM_ACCESSTOKEN")


    # API URL
    url = f"https://dev.azure.com/{organization}/{project}/_apis/test/Plans/{plan_id}/Suites/{suite_id}/TestCases?api-version=7.0"

    # Headers for authentication
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Basic {pat}"
    }

    # Make GET request
    response = requests.get(url, headers=headers)

    # Check response
    if response.status_code == 200:
        test_cases = response.json()
        print(json.dumps(test_cases, indent=4))  # Pretty print the JSON response
    else:
        print(f"❌ Failed to retrieve test cases. Status code: {response.status_code}")
        print(response.text)
