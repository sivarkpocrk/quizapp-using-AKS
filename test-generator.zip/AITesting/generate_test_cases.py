import os
import openai

def generate_test_cases(acceptance_criteria):
    """
    Generates structured test cases based on acceptance criteria using OpenAI GPT-4.

    Args:
        acceptance_criteria (str): The extracted acceptance criteria.

    Returns:
        str: Generated test cases.
    """
    print(f"Acceptance Criteria at the start:\n{acceptance_criteria}\n")

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("Error: OPENAI_API_KEY is not set.")
        return "ERROR: Missing API key."

    try:
        openai.api_key = api_key
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{
                    "role": "system",
                    "content": "You are an expert software tester. Generate structured test cases including test steps, expected results, and pass/fail conditions for multiple scenarios, if applicable."
                },
                {
                    "role": "user",
                    "content": f"Based on the following acceptance criteria, generate multiple test cases with detailed steps, expected results, and pass/fail conditions for each scenario, also, give anyother fail condition:\n\n{acceptance_criteria}"
                }
            ],
            max_tokens=1500  # Increased token limit to allow multiple test cases
        )

        test_cases = response['choices'][0]['message']['content'].strip()

        print(f"Generated Test Cases:\n{test_cases}\n" + "-" * 50)
        return test_cases

    except Exception as e:
        print(f"Error generating test cases:\n{e}")
        return "ERROR: Failed to generate test cases."

def main():
    """
    Reads the acceptance criteria from ac.txt, generates multiple test cases, and saves them to 'generated_test_script.txt'.
    """
    ac_file = "ac.txt"
    output_file = "generated_test_script.txt"

    if not os.path.exists(ac_file):
        print(f"Error: {ac_file} not found. Ensure previous pipeline steps ran successfully.")
        return

    try:
        with open(ac_file, "r") as file:
            acceptance_criteria = file.read().strip()

        if not acceptance_criteria:
            print("Error: Acceptance criteria file is empty.")
            return

        print(f"Acceptance Criteria:\n{acceptance_criteria}\n" + "-" * 50)

        # Generate test cases
        generated_tests = generate_test_cases(acceptance_criteria)

        # Save generated test cases to the output file
        with open(output_file, "w", encoding="utf-8") as output:
            output.write(generated_tests)

        print(f"Generated test cases saved to {output_file}")

    except Exception as e:
        print(f"Error processing acceptance criteria: {e}")

if __name__ == "__main__":
    main()
