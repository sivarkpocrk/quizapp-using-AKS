import os
import sys
import json
import openai

def generate_test_cases(acceptance_criteria):
    """
    Generates structured test cases based on acceptance criteria using OpenAI GPT-4.

    Returns:
        tuple: A list of test case dicts and the raw Python code string defining `test_cases`.
    """
    # Ensure API key is set
    openai.api_key = os.getenv("OPENAI_API_KEY")
    if not openai.api_key:
        print("Error: OPENAI_API_KEY is not set.", file=sys.stderr)
        sys.exit(1)

    # System prompt: enforce exact Python output format
    system_prompt = (
        "You are an expert software tester. "
        "When you output your test cases, format them *only* as a Python variable named `test_cases` "
        "and assign it a list of dicts, where each dict has:\n"
        "- a string field `title`\n"
        "- a list field `steps`, each item of which is a dict with:\n"
        "    - string field `action`\n"
        "    - string field `expected`\n\n"
        "Do not wrap your answer in prose—output *only* valid Python code, e.g.:\n"
        "```python\n"
        "test_cases = [\n"
        "    {\n"
        "        \"title\": \"...\",\n"
        "        \"steps\": [\n"
        "            {\"action\": \"...\", \"expected\": \"...\"},\n"
        "            ...\n"
        "        ]\n"
        "    },\n"
        "    ...\n"
        "]\n"
        "```"
    )

    # Prepare messages
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"Based on the following acceptance criteria, generate test cases:\n\n{acceptance_criteria}"}
    ]

    try:
        # Call OpenAI API
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=messages,
            max_tokens=1500,
            temperature=0
        )
        raw_content = response.choices[0].message.content.strip()

        # Execute the returned code to extract `test_cases`
        namespace = {}
        exec(raw_content, {}, namespace)
        test_cases = namespace.get("test_cases")


        print(f"Generated Test Cases:\n{test_cases}\n" + "-" * 50)

        print(f"Generated Test Cases Raw Content:\n{raw_content}\n" + "-" * 50)

        if test_cases is None:
            print("Error: 'test_cases' variable not found in the model response.", file=sys.stderr)
            sys.exit(1)

        return test_cases, raw_content

    except Exception as e:
        print(f"Error generating test cases: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    # Input and output file paths
    ac_file = "ac.txt"
    script_py = "generated_test_cases_example.py"
    script_json = "generated_test_cases_example.json"

    # Read acceptance criteria
    if not os.path.exists(ac_file):
        print(f"Error: {ac_file} not found. Ensure it exists in the current directory.", file=sys.stderr)
        sys.exit(1)

    with open(ac_file, "r", encoding="utf-8") as f:
        acceptance_criteria = f.read().strip()

    if not acceptance_criteria:
        print("Error: Acceptance criteria file is empty.", file=sys.stderr)
        sys.exit(1)

    # Generate and parse test cases
    test_cases, raw_code = generate_test_cases(acceptance_criteria)

    # Save the raw Python code defining test_cases
    with open(script_py, "w", encoding="utf-8") as f:
        f.write(raw_code + "\n")

    # Save the parsed test cases to JSON
    with open(script_json, "w", encoding="utf-8") as f:
        json.dump(test_cases, f, indent=4)

    print(f"Test cases successfully generated!\n- Python script: {script_py}\n- JSON output: {script_json}")

if __name__ == "__main__":
    main()
